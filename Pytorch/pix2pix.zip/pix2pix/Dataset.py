import os
from PIL import Image
from torch.utils.data import Dataset
class CustomDataset(Dataset):
  def __init__(self,root_A,root_B,transform=None):
    self.root_A=root_A
    self.root_B=root_B
    self.transform=transform
    self.files_A=sorted(os.listdir(root_A))
    self.files_B=sorted(os.listdir(root_B))

  def __len__(self):
    assert len(self.files_A)==len(self.files_B),"The number of images in A and B must be same"
    return len(self.files_A)
  def __getitem__(self, index):
    img_path_A=os.path.join(self.root_A,self.files_A[index])
    img_path_B=os.path.join(self.root_B,self.files_B[index])
    img_A=Image.open(img_path_A)
    img_B=Image.open(img_path_B)

    if self.transform:
      img_A=self.transform(img_A)
      img_B=self.transform(img_B)
    return img_A,img_B