import torch
from torch import nn
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from torch import optim
import matplotlib.pyplot as plt
from tqdm import tqdm
from torch.cuda.amp import GradScaler,autocast
from generator import Generator
from Discriminator import Discriminator
from Dataset import CustomDataset
from PIL import Image
device=torch.device("cuda")

epochs=300
batch_size=8
lr=2e-4
lambda_pixel=100

generator=Generator().to(device)
discriminator=Discriminator().to(device)


criterion=nn.MSELoss()
criterion_pixelwise=nn.L1Loss()
optim_G=optim.Adam(generator.parameters(),lr=lr)
optim_D=optim.Adam(Discriminator.parameters(),lr=lr)

transform=transforms.Compose([
  transforms.Resize((256,256),Image.BICUBIC),
  transforms.ToTensor(),
  transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])
dataset=CustomDataset(root_A="",root_B="",transform=transform)
loader=DataLoader(dataset,batch_size=batch_size,shuffle=False)

d_scaler=GradScaler()
g_scaler=GradScaler()
for epoch in range(epochs):
  for i,(x,y) in enumerate(tqdm(loader,desc="Epoch={epoch+1}/epochs")):
    x=x.to(device)
    y=y.to(device)

    with autocast():
      y_fake=generator(x)
      disc_fake=discriminator(x,y_fake.detach())
      d_loss_fake=criterion(disc_fake,torch.zeros_like(disc_fake))
      disc_real=discriminator(x,y)
      d_loss_real=criterion(disc_real,torch.ones_like(disc_real))
      d_loss=(d_loss_fake+d_loss_real)/2
    optim_D.zero_grad()
    d_scaler.scale(d_loss).backward()
    d_scaler.step(optim_D)
    d_scaler.update()
    with autocast():
      d_fake=discriminator(x,y_fake)
      g_fake_loss=criterion(d_fake,torch.ones_like(d_fake))
      l1=criterion_pixelwise(y_fake,y)*lambda_pixel
      g_loss=g_fake_loss+l1
    optim_G.zero_grad()
    g_scaler.scale(g_loss).backward()
    g_scaler.step(optim_G)
    g_scaler.update()
    print(f"Epoch [{epoch+1}/{epochs}] Loss D:{d_loss.item():.4f},Loss G:{g_loss.item():.4f}")
    if epoch%10==0:
      torch.save(generator.state_dict(),f"generator_epoch_{epoch+1}.pth")
      torch.save(discriminator.state_dict(),f"discriminator_epoch_{epoch+1}.pth")
      with torch.no_grad():
        y_fake=generator(x)
        x=transforms.ToPILImage()(x[0].cpu())
        y=transforms.ToPILImage()(y[0].cpu())
        y_fake=transforms.ToPILImage()(y_fake[0].cpu())
        plt.figure(figsize=(10,5))
        plt.subplot(1,3,1)
        plt.title("Input Image")
        plt.imshow(x)
        plt.subplot(1,3,2)
        plt.title("Ground Truth")
        plt.imshow(y)
        plt.subplot(1,3,3)
        plt.title("Generated Image")
        plt.imshow(y_fake)
        plt.show()

def evaluate_model(generator, dataloader, device):
    generator.eval()
    with torch.no_grad():
        for i, (real_A, real_B) in enumerate(tqdm(dataloader, desc="Evaluating")):
            real_A = real_A.to(device)
            real_B = real_B.to(device)
            fake_B = generator(real_A)

            real_A_img = transforms.ToPILImage()(real_A[0].cpu())
            real_B_img = transforms.ToPILImage()(real_B[0].cpu())
            fake_B_img = transforms.ToPILImage()(fake_B[0].cpu())

            plt.figure(figsize=(10,5))
            plt.subplot(1,3,1)
            plt.title('Input Image')
            plt.imshow(real_A_img)
            plt.subplot(1,3,2)
            plt.title('Ground Truth')
            plt.imshow(real_B_img)
            plt.subplot(1,3,3)
            plt.title('Generated Image')
            plt.imshow(fake_B_img)
            plt.show()
test_dataset = CustomDataset(root_A='path_to_your_test_dataset_A', root_B='path_to_your_test_dataset_B', transform=transform)
test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=4)
evaluate_model(generator, test_dataloader, device)